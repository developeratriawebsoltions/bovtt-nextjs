// app/api/contacts/bulk/route.ts
import { NextRequest, NextResponse } from 'next/server';
import mysql from 'mysql2/promise';

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
});

export async function POST(request: NextRequest) {
  try {
    const { contacts } = await request.json();

    if (!contacts || !Array.isArray(contacts) || contacts.length === 0) {
      return NextResponse.json({ error: 'No contacts provided' }, { status: 400 });
    }

    let inserted = 0;
    let updated = 0;
    let skipped = 0;
    const errors: string[] = [];

    for (const contact of contacts) {
      try {
        // Normalize phone: strip spaces, dashes, parentheses; ensure leading +
        let phone = String(contact.phone || '').replace(/[\s\-\(\)]/g, '').trim();
        if (!phone) { skipped++; continue; }
        // If phone is all digits and 10 chars, assume Indian number
        if (/^\d{10}$/.test(phone)) phone = '+91' + phone;
        // If starts with 91 and 12 digits total, add +
        else if (/^91\d{10}$/.test(phone)) phone = '+' + phone;
        // If no +, add it
        else if (!phone.startsWith('+')) phone = '+' + phone;

        const name = String(contact.name || '').trim();
        if (!name) { skipped++; continue; }

        const label = contact.label || 'none';

        const [existing] = await pool.query(
          'SELECT id FROM contacts WHERE phone = ?',
          [phone]
        );

        if ((existing as any[]).length > 0) {
          await pool.query(
            'UPDATE contacts SET name = ?, label = ?, updated_at = NOW() WHERE phone = ?',
            [name, label, phone]
          );
          updated++;
        } else {
          await pool.query(
            'INSERT INTO contacts (phone, name, label, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())',
            [phone, name, label]
          );
          inserted++;
        }
      } catch (err: any) {
        errors.push(`Row ${contact.phone}: ${err.message}`);
      }
    }

    return NextResponse.json({
      success: true,
      summary: { inserted, updated, skipped, errors: errors.length },
      errors: errors.slice(0, 10), // return first 10 errors only
    });
  } catch (error: any) {
    console.error('Bulk upload error:', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}